
# Imprint / Company

### Pre‑launch notice
*The Service is not yet available in Poland. This page is provided for informational purposes only. These terms/policies will take effect on the public launch date.*

**Last updated:** September 8, 2025

**Operator:** **Sigma Clinic sp. z o.o.**  
**Seat / Address:** Młynarska 42, 01-171 Warszawa, Poland  
**KRS:** 0001184102 • **EUID:** PLKRS.0001184102 • **NIP (VAT):** 5273173475 • **REGON:** 542251538  
**Email:** **support@sigma.clinic**

*Optional (German-language pages only):*  
**Responsible for content pursuant to § 18 Abs. 2 MStV:** Michał M. Wrodarczyk, Młynarska 42, 01-171 Warszawa, Poland.
